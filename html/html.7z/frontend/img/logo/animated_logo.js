(function (lib, img, cjs) {

var p; // shortcut to reference prototypes

// stage content:
(lib.animated_logo = function() {
	this.initialize();

	// Layer 2
	this.instance = new lib.Symbol7();
	this.instance.setTransform(124.5,162.7,0.516,0.486,0,0,0,31.8,35.3);

	this.instance_1 = new lib.Symbol5();
	this.instance_1.setTransform(79.1,180,0.516,0.486,0,0,0,18.6,41.3);

	this.instance_2 = new lib.Symbol3();
	this.instance_2.setTransform(31,150,0.516,0.486,0,0,0,41,27.9);

	this.instance_3 = new lib.Symbol1();
	this.instance_3.setTransform(19.6,109.6,0.516,0.486,0,0,0,38,18.2);

	// Layer 1
	this.instance_4 = new lib.Symbol9();
	this.instance_4.setTransform(85.4,116.4,0.516,0.486,0,0,0,84.8,85.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#171717").s().p("AmfJSQiripAAj4QABj2CrirQCtiqD5AAQD1AACnCmQCnCnAADyIgFBPIp/AAQgPgwAAgpQABg5AUg2IDVAAQgXh7h3AAQhMAAgzBDQgxBBAABpQAABuAwBEQAwBEBMAAQA/AAA7hAIDxEiQioCEjPAAQj4AAiriogAh4nzIDskGIEMAAIkMEGg");
	this.shape.setTransform(565.7,114.3,0.516,0.486);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#171717").s().p("Aj+LXQh4g3hOheQiIijAAkDIAAupIGnAAIAAOaQAADgCiAAQBCAAAxguQAvgvAAhDQAAhFgtgvQgsgvhCAAQgtAAg7ApIAAnQQBKgHAkAAQDvABCqCrQCqCsAADwQAAD3itCqQitCpj6AAQh+AAh5g3g");
	this.shape_1.setTransform(502.6,113.3,0.516,0.486);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#171717").s().p("Aj9MbIAAmBQBTAtBUAAQBxAAA+hLQA+hKAAiNIAAmmQAAixiQAAQg7AAguAvQgtAvAAA9QAABBArAqQAsArA+AAQArAAAogUIAAGCQhaAihUAAQjMgBiOiaQiOiZAAjgQAAjyCrimQCqimD3AAQCFAAB4A1QB5A1BFBZQB0CVAAEZIAAFxQgBEtirC8QirC8kRAAQhTAAiAgpg");
	this.shape_2.setTransform(434.7,135.1,0.516,0.486);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#171717").s().p("AmhGjQiqinAAj8QAAj0CriqQCsirD0AAQERABCdCfQCeCgAAETIAAIoImnAAIAAoKQAAhXgrg1Qgsg1hJAAQhBAAgxAxQgwAwAABBQAABGAsAtQAsAtBEAAQA1AAAvgdIAAG1QgzAJgrAAIgCAAQj7AAiping");
	this.shape_3.setTransform(369.3,122.9,0.516,0.486);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#171717").s().p("AmfJlQitiqAAj2QAAjtCriuQCtiuDqAAQAkABBMAGIAAHQQg0gpgzAAQhAAAgwAwQgvAwAABEQAABCAxAvQAwAuBCAAQCjAAAAjgIAAuaIGnAAIAAOpQAAEDiICjQhOBeh4A3Qh5A3h+AAIgBAAQj6AAisipg");
	this.shape_4.setTransform(304.2,113.3,0.516,0.486);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#171717").s().p("AmhGjQiqinAAj8QAAj0CriqQCsirD0AAQERABCdCfQCeCgAAETIAAIoImnAAIAAoKQAAhXgrg1Qgsg1hJAAQhBAAgxAxQgwAwAABBQAABGAsAtQAsAtBEAAQA1AAAvgdIAAG1QgzAJgrAAIgCAAQj7AAiping");
	this.shape_5.setTransform(237.9,122.9,0.516,0.486);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#171717").s().p("AnBuPIOCAAIAAUzQkigKjiB2QjzB+iLECg");
	this.shape_6.setTransform(65.1,50.1,0.516,0.486);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#171717").s().p("AizWHQh3hZiFjiQBHi1gEjEQgFjBhNiwQhQiziOiCQiWiHjJg+IAB1WIOEAAIAAd3QAABAALA2QAJArAOAdQAMAXAdANQAcAMAiAAQBAAAAZg7QAWg1AAh+IAA93IN6AAMAAAAhJQAADRg0CfQg4Coh3B9Qh7CBiUA+QiXBAjAAAQjZAAiNhog");
	this.shape_7.setTransform(153.3,79.8,0.516,0.486);

	this.addChild(this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,5.7,596,194.3);


// symbols:
(lib.Symbol10 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFAF","#FFF9A7","#FFDA7D","#FFC05B","#FFAC40","#FF9E2D","#FF9622","#FF931E"],[0,0.027,0.18,0.337,0.498,0.659,0.824,1],0,0,0,0,0,84.9).s().p("AlDMSQiehBh4h5Qhzh1hAiaQhAiZgCimQgCipBBifQBnj+DuiTQDpiPEKAOQgHB1ADDuIAEEUQAAA/AlAmQAiAiAwABQAxAAAigiQAlgnABhEIAFj3QAEiugCiLQCgBBB7B6QB3B2BECZQBECbAEClQAFCrhBCfQhBCfh6B4Qh2B0iaBAQiaBAimABIgIAAQimAAichAg");
	this.shape.setTransform(84.7,85.1);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,169.5,170.2);


(lib.Symbol8 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFB0","#FFF8A7","#FFD97D","#FFC05B","#FFAC40","#FF9E2D","#FF9622","#FF931E"],[0,0.031,0.184,0.341,0.498,0.659,0.824,1],25.3,27.8,-23.7,-31.5).s().p("AEfFcQgJgOgGgEIpNmgQBxg6BHg+QArgmBchsIE0KPQAHASABAIQABAOgMAHQgFADgEAAQgGAAgFgFg");
	this.shape.setTransform(17,16,1,1,0,0,0,-14.8,-19.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,63.7,70.7);


(lib.Symbol6 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFB0","#FFF8A7","#FFD97D","#FFC05B","#FFAC40","#FF9E2D","#FF9622","#FF931E"],[0,0.031,0.184,0.341,0.498,0.659,0.824,1],-8.4,34.5,1.7,-53.2).s().p("AhwGbQgsl+gMiBQgek8AXAFQARAEA+AVQAuAQAqADQAeADBAAAQBIABAcABIkdMGg");
	this.shape.setTransform(18.6,41.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,37.3,82.5);


(lib.Symbol4 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFB0","#FFF8A7","#FFD97D","#FFC05B","#FFAC40","#FF9E2D","#FF9622","#FF931E"],[0,0.031,0.184,0.341,0.498,0.659,0.824,1],-24.6,29.8,39.1,-18.9).s().p("AmWEMQgKgKARgOQBrhbDvjhQDSjKAHgDQApBnBCBTQAkAuBoBlIsCDbQgMADgKAAQgQAAgJgKg");
	this.shape.setTransform(41.1,27.9);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,82.3,55.8);


(lib.Symbol2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFB0","#FFF8A7","#FFD97D","#FFC05B","#FFAC40","#FF9E2D","#FF9622","#FF931E"],[0,0.031,0.184,0.341,0.498,0.659,0.824,1],-27.2,-1.8,49.3,0.4).s().p("Al8g1IL5h/QgjBhgPBUQgPBVAABfg");
	this.shape.setTransform(38.1,18.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,76.3,36.4);


(lib.Symbol11 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,177,152,0)").s().p("ApzJ0QkEkFAAlvQAAluEEkFQEEkEFvAAQAiABAbACQFJAUDuDtQEEEFAAFuQAAFvkEEFQkEEDlwABQlvgBkEkDg");
	this.shape.setTransform(84.6,84.9,0.953,0.956);

	this.instance = new lib.Symbol10();
	this.instance.setTransform(84.7,85,1,1,0,0,0,84.7,85);

	this.addChild(this.instance,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,169.5,170.2);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol11();
	this.instance.setTransform(84.7,85,1,1,0,0,0,84.7,85);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:85.1,y:85.1},0).wait(23));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,169.5,170.2);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol8();
	this.instance.setTransform(16.1,16,1,1,0,0,0,16.1,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:31.8,regY:35.3,scaleX:0.98,scaleY:0.98,x:31.4,y:34.9},0).wait(1).to({scaleX:0.95,scaleY:0.96,x:31.1,y:34.5},0).wait(1).to({scaleX:0.93,scaleY:0.94,x:30.7,y:34.1},0).wait(1).to({scaleX:0.91,scaleY:0.91,x:30.3,y:33.6},0).wait(1).to({scaleX:0.88,scaleY:0.89,x:30,y:33.2},0).wait(1).to({scaleX:0.86,scaleY:0.87,x:29.6,y:32.8},0).wait(1).to({scaleX:0.84,scaleY:0.85,x:29.3,y:32.4},0).wait(1).to({scaleX:0.82,scaleY:0.83,x:28.9,y:32},0).wait(1).to({scaleX:0.79,scaleY:0.81,x:28.5,y:31.6},0).wait(1).to({scaleX:0.77,scaleY:0.79,x:28.2,y:31.2},0).wait(1).to({scaleX:0.75,scaleY:0.76,x:27.8,y:30.7},0).wait(1).to({scaleX:0.72,scaleY:0.74,x:27.4,y:30.3},0).wait(1).to({scaleX:0.7,scaleY:0.72,x:27.1,y:29.9},0).wait(1).to({scaleX:0.68,scaleY:0.7,x:26.7,y:29.5},0).wait(1).to({scaleX:0.65,scaleY:0.68,x:26.3,y:29.1},0).wait(1).to({scaleX:0.63,scaleY:0.66,x:26,y:28.7},0).wait(1).to({scaleX:0.61,scaleY:0.64,x:25.6,y:28.3},0).wait(1).to({scaleX:0.58,scaleY:0.61,x:25.3,y:27.9},0).wait(1).to({scaleX:0.56,scaleY:0.59,x:24.9,y:27.4},0).wait(1).to({scaleX:0.54,scaleY:0.57,x:24.5,y:27},0).wait(1).to({scaleX:0.51,scaleY:0.55,x:24.1,y:26.6},0).wait(1).to({scaleX:0.54,scaleY:0.57,x:24.6,y:27.1},0).wait(1).to({scaleX:0.56,scaleY:0.6,x:25,y:27.5},0).wait(1).to({scaleX:0.59,scaleY:0.62,x:25.4,y:27.9},0).wait(1).to({scaleX:0.62,scaleY:0.65,x:25.8,y:28.4},0).wait(1).to({scaleX:0.64,scaleY:0.67,x:26.2,y:28.9},0).wait(1).to({scaleX:0.67,scaleY:0.69,x:26.6,y:29.4},0).wait(1).to({scaleX:0.69,scaleY:0.72,x:27,y:29.8},0).wait(1).to({scaleX:0.72,scaleY:0.74,x:27.4,y:30.3},0).wait(1).to({scaleX:0.74,scaleY:0.76,x:27.8,y:30.7},0).wait(1).to({scaleX:0.77,scaleY:0.79,x:28.2,y:31.2},0).wait(1).to({scaleX:0.8,scaleY:0.81,x:28.6,y:31.6},0).wait(1).to({scaleX:0.82,scaleY:0.83,x:29,y:32.1},0).wait(1).to({scaleX:0.85,scaleY:0.86,x:29.4,y:32.6},0).wait(1).to({scaleX:0.87,scaleY:0.88,x:29.8,y:33},0).wait(1).to({scaleX:0.9,scaleY:0.91,x:30.2,y:33.5},0).wait(1).to({scaleX:0.92,scaleY:0.93,x:30.6,y:33.9},0).wait(1).to({scaleX:0.95,scaleY:0.95,x:31,y:34.4},0).wait(1).to({scaleX:0.97,scaleY:0.98,x:31.4,y:34.8},0).wait(1).to({scaleX:1,scaleY:1,x:31.8,y:35.3},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,63.7,70.7);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol6();
	this.instance.setTransform(20.2,5.4,1,1,0,0,0,20.2,5.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:18.6,regY:41.2,scaleX:0.98,scaleY:0.97,x:18.6,y:40.1},0).wait(1).to({scaleX:0.96,scaleY:0.94,x:18.7,y:38.9},0).wait(1).to({scaleX:0.94,scaleY:0.9,y:37.8},0).wait(1).to({scaleX:0.91,scaleY:0.87,y:36.6},0).wait(1).to({scaleX:0.89,scaleY:0.84,x:18.8,y:35.5},0).wait(1).to({scaleX:0.87,scaleY:0.81,y:34.3},0).wait(1).to({scaleX:0.85,scaleY:0.78,x:18.9,y:33.2},0).wait(1).to({scaleX:0.83,scaleY:0.74,x:18.8,y:32},0).wait(1).to({scaleX:0.81,scaleY:0.71,x:18.9,y:30.9},0).wait(1).to({scaleX:0.78,scaleY:0.68,y:29.7},0).wait(1).to({scaleX:0.76,scaleY:0.65,x:19,y:28.6},0).wait(1).to({scaleX:0.74,scaleY:0.62,y:27.4},0).wait(1).to({scaleX:0.72,scaleY:0.58,y:26.3},0).wait(1).to({scaleX:0.7,scaleY:0.55,x:19.1,y:25.1},0).wait(1).to({scaleX:0.68,scaleY:0.52,y:24},0).wait(1).to({scaleX:0.65,scaleY:0.49,y:22.8},0).wait(1).to({scaleX:0.68,scaleY:0.52,y:24},0).wait(1).to({scaleX:0.7,scaleY:0.56,y:25.3},0).wait(1).to({scaleX:0.72,scaleY:0.59,x:19,y:26.5},0).wait(1).to({scaleX:0.75,scaleY:0.62,y:27.7},0).wait(1).to({scaleX:0.77,scaleY:0.66,y:28.9},0).wait(1).to({scaleX:0.79,scaleY:0.69,x:18.9,y:30.2},0).wait(1).to({scaleX:0.82,scaleY:0.73,y:31.4},0).wait(1).to({scaleX:0.84,scaleY:0.76,y:32.6},0).wait(1).to({scaleX:0.86,scaleY:0.8,x:18.8,y:33.9},0).wait(1).to({scaleX:0.88,scaleY:0.83,y:35.1},0).wait(1).to({scaleX:0.91,scaleY:0.86,y:36.3},0).wait(1).to({scaleX:0.93,scaleY:0.9,x:18.7,y:37.5},0).wait(1).to({scaleX:0.95,scaleY:0.93,y:38.8},0).wait(1).to({scaleX:0.98,scaleY:0.97,x:18.6,y:40},0).wait(1).to({scaleX:1,scaleY:1,y:41.2},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,37.3,82.5);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol4();
	this.instance.setTransform(82.9,1.7,1,1,0,0,0,82.9,1.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:41.1,regY:27.9,scaleX:0.98,scaleY:0.99,x:41.6,y:27.7},0).wait(1).to({scaleX:0.97,scaleY:0.98,x:42.2,y:27.6},0).wait(1).to({scaleX:0.95,scaleY:0.97,x:42.7,y:27.4},0).wait(1).to({scaleX:0.94,scaleY:0.96,x:43.3,y:27.2},0).wait(1).to({scaleX:0.92,scaleY:0.95,x:43.8,y:27},0).wait(1).to({scaleX:0.91,scaleY:0.93,x:44.4,y:26.9},0).wait(1).to({scaleX:0.89,scaleY:0.92,x:44.9,y:26.7},0).wait(1).to({scaleX:0.87,scaleY:0.91,x:45.5,y:26.6},0).wait(1).to({scaleX:0.86,scaleY:0.9,x:46,y:26.3},0).wait(1).to({scaleX:0.84,scaleY:0.89,x:46.6,y:26.2},0).wait(1).to({scaleX:0.83,scaleY:0.88,x:47.1,y:26},0).wait(1).to({scaleX:0.81,scaleY:0.87,x:47.7,y:25.9},0).wait(1).to({scaleX:0.79,scaleY:0.86,x:48.2,y:25.7},0).wait(1).to({scaleX:0.78,scaleY:0.85,x:48.7,y:25.5},0).wait(1).to({scaleX:0.76,scaleY:0.83,x:49.3,y:25.3},0).wait(1).to({scaleX:0.75,scaleY:0.82,x:49.8,y:25.2},0).wait(1).to({scaleX:0.73,scaleY:0.81,x:50.4,y:25},0).wait(1).to({scaleX:0.72,scaleY:0.8,x:50.9,y:24.8},0).wait(1).to({scaleX:0.7,scaleY:0.79,x:51.4,y:24.7},0).wait(1).to({scaleX:0.68,scaleY:0.78,x:52,y:24.5},0).wait(1).to({scaleX:0.67,scaleY:0.77,x:52.5,y:24.3},0).wait(1).to({scaleX:0.65,scaleY:0.76,x:53.1,y:24.2},0).wait(1).to({scaleX:0.64,scaleY:0.75,x:53.6,y:24},0).wait(1).to({scaleX:0.62,scaleY:0.73,x:54.2,y:23.8},0).wait(1).to({scaleX:0.6,scaleY:0.72,x:54.7,y:23.7},0).wait(1).to({scaleX:0.62,scaleY:0.74,x:54.1,y:23.9},0).wait(1).to({scaleX:0.64,scaleY:0.75,x:53.5,y:24.1},0).wait(1).to({scaleX:0.66,scaleY:0.76,x:52.9,y:24.2},0).wait(1).to({scaleX:0.68,scaleY:0.77,x:52.2,y:24.4},0).wait(1).to({scaleX:0.69,scaleY:0.79,x:51.6,y:24.6},0).wait(1).to({scaleX:0.71,scaleY:0.8,x:51,y:24.8},0).wait(1).to({scaleX:0.73,scaleY:0.81,x:50.4,y:25},0).wait(1).to({scaleX:0.75,scaleY:0.82,x:49.8,y:25.2},0).wait(1).to({scaleX:0.77,scaleY:0.84,x:49.2,y:25.4},0).wait(1).to({scaleX:0.78,scaleY:0.85,x:48.5,y:25.6},0).wait(1).to({scaleX:0.8,scaleY:0.86,x:47.9,y:25.8},0).wait(1).to({scaleX:0.82,scaleY:0.87,x:47.3,y:26},0).wait(1).to({scaleX:0.84,scaleY:0.89,x:46.7,y:26.2},0).wait(1).to({scaleX:0.86,scaleY:0.9,x:46.1,y:26.4},0).wait(1).to({scaleX:0.87,scaleY:0.91,x:45.4,y:26.6},0).wait(1).to({scaleX:0.89,scaleY:0.93,x:44.8,y:26.7},0).wait(1).to({scaleX:0.91,scaleY:0.94,x:44.2,y:26.9},0).wait(1).to({scaleX:0.93,scaleY:0.95,x:43.6,y:27.1},0).wait(1).to({scaleX:0.95,scaleY:0.96,x:43,y:27.3},0).wait(1).to({scaleX:0.96,scaleY:0.98,x:42.3,y:27.5},0).wait(1).to({scaleX:0.98,scaleY:0.99,x:41.7,y:27.7},0).wait(1).to({scaleX:1,scaleY:1,x:41.1,y:27.9},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,82.3,55.8);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol2();
	this.instance.setTransform(38.1,18.2,1,1,0,0,0,38.1,18.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:0.99,scaleY:0.99,x:38.6},0).wait(1).to({scaleX:0.98,scaleY:0.97,x:39.1},0).wait(1).to({scaleX:0.96,scaleY:0.96,x:39.6},0).wait(1).to({scaleX:0.95,scaleY:0.95,x:40},0).wait(1).to({scaleX:0.94,scaleY:0.93,x:40.5},0).wait(1).to({scaleX:0.93,scaleY:0.92,x:41},0).wait(1).to({scaleX:0.92,scaleY:0.9,x:41.4},0).wait(1).to({scaleX:0.91,scaleY:0.89,x:41.9},0).wait(1).to({scaleX:0.89,scaleY:0.88,x:42.4},0).wait(1).to({scaleX:0.88,scaleY:0.86,x:42.9},0).wait(1).to({scaleX:0.87,scaleY:0.85,x:43.4},0).wait(1).to({scaleX:0.86,scaleY:0.84,x:43.9},0).wait(1).to({scaleX:0.85,scaleY:0.82,x:44.3},0).wait(1).to({scaleX:0.83,scaleY:0.81,x:44.8},0).wait(1).to({scaleX:0.82,scaleY:0.79,x:45.3},0).wait(1).to({scaleX:0.81,scaleY:0.78,x:45.8},0).wait(1).to({scaleX:0.8,scaleY:0.77,x:46.3},0).wait(1).to({scaleX:0.79,scaleY:0.75,x:46.8},0).wait(1).to({scaleX:0.77,scaleY:0.74,x:47.2},0).wait(1).to({scaleX:0.76,scaleY:0.73,x:47.7},0).wait(1).to({scaleX:0.75,scaleY:0.71,x:48.2},0).wait(1).to({scaleX:0.74,scaleY:0.7,x:48.7},0).wait(1).to({scaleX:0.73,scaleY:0.68,x:49.1},0).wait(1).to({scaleX:0.71,scaleY:0.67,x:49.6},0).wait(1).to({scaleX:0.7,scaleY:0.66,x:50.1},0).wait(1).to({scaleX:0.69,scaleY:0.64,x:50.6},0).wait(1).to({scaleX:0.68,scaleY:0.63,x:51.1},0).wait(1).to({scaleX:0.67,scaleY:0.61,x:51.6},0).wait(1).to({scaleX:0.68,scaleY:0.63,x:51.1},0).wait(1).to({scaleX:0.69,scaleY:0.64,x:50.5},0).wait(1).to({scaleX:0.71,scaleY:0.66,x:50},0).wait(1).to({scaleX:0.72,scaleY:0.67,x:49.5},0).wait(1).to({scaleX:0.73,scaleY:0.69,x:49},0).wait(1).to({scaleX:0.74,scaleY:0.7,x:48.5},0).wait(1).to({scaleX:0.76,scaleY:0.72,x:47.9},0).wait(1).to({scaleX:0.77,scaleY:0.73,x:47.4},0).wait(1).to({scaleX:0.78,scaleY:0.75,x:46.9},0).wait(1).to({scaleX:0.8,scaleY:0.76,x:46.4},0).wait(1).to({scaleX:0.81,scaleY:0.78,x:45.8},0).wait(1).to({scaleX:0.82,scaleY:0.79,x:45.3},0).wait(1).to({scaleX:0.83,scaleY:0.81,x:44.8},0).wait(1).to({scaleX:0.85,scaleY:0.82,x:44.3},0).wait(1).to({scaleX:0.86,scaleY:0.84,x:43.8},0).wait(1).to({scaleX:0.87,scaleY:0.85,x:43.3},0).wait(1).to({scaleX:0.89,scaleY:0.87,x:42.8},0).wait(1).to({scaleX:0.9,scaleY:0.88,x:42.2},0).wait(1).to({scaleX:0.91,scaleY:0.9,x:41.7},0).wait(1).to({scaleX:0.92,scaleY:0.91,x:41.2},0).wait(1).to({scaleX:0.94,scaleY:0.93,x:40.7},0).wait(1).to({scaleX:0.95,scaleY:0.94,x:40.2},0).wait(1).to({scaleX:0.96,scaleY:0.96,x:39.7},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:39.1},0).wait(1).to({scaleX:0.99,scaleY:0.99,x:38.6},0).wait(1).to({scaleX:1,scaleY:1,x:38.1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,76.3,36.4);

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;